import Foundation
import XCTest
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true
URLCache.shared = URLCache(memoryCapacity: 0, diskCapacity: 0, diskPath: nil)

class Carga {
    var datos:[String] = []
    var datosAsync:[[String:Any]] = [[:]]
    
    init() {
        if let ruta = Bundle.main.path(forResource: "datos1", ofType: "plist"), let datos = FileManager.default.contents(atPath: ruta) {
            do {
                if let cargaInicial = try PropertyListSerialization.propertyList(from: datos, options: [], format: nil) as? [String:Any] {
                    self.datos = cargaInicial["pokemons"] as! [String]
                }
            } catch {
                print(error.localizedDescription)
            }
        }
    }
    
    func cargaAsync() {
        if let rutaURL = URL(string: "https://jsonplaceholder.typicode.com/users") {
            let request = URLRequest(url: rutaURL)
            let session = URLSession.shared
            let task = session.dataTask(with: request) {
                [unowned self] (data, response, error) in
                do {
                    guard let data = data, error == nil else { print(error!.localizedDescription); return }
                    self.datosAsync = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as! [[String:Any]]
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue:"cargaCompletada"), object: self)
                } catch {
                    print("Fallo en la carga del JSON")
                }
            }
            task.resume()
        }
    }
}

let carga = Carga()

class TestCarga:XCTestCase {
    var carga:Carga!
    
    override func setUp() {
        carga = Carga()
        super.setUp()
    }
    
    override func tearDown() {
        super.tearDown()
        carga = nil
    }
    
    func testCarga() {
        XCTAssertEqual(carga.datos.count, 24)
    }

    func testWaitCargaAsync() {
        let expectacion = XCTNSNotificationExpectation(name: "cargaCompletada", object: carga, notificationCenter: NotificationCenter.default)
        carga.cargaAsync()
        let waiter = XCTWaiter()
        waiter.delegate = self
        waiter.wait(for: [expectacion], timeout: 5)
    }
}

let test = TestCarga.defaultTestSuite()
test.run()
